/** A playing card rank type designed for cribbage.  It supports a single-
 *  character abbreviation for each rank, as well as providing the face
 *  value of a rank (ACE=1, KING, QUEEN, and JACK=10, other ranks are their
 *  face value), needed for counting 15s in a cribbage hand.  Also provides
 *  methods to get the next smaller and larger rank of a given rank. 
 *  
 *  In a addition to the code provided, I have added one method, fromString, 
 *  which converts a given character into the associated cribbage rank object.
 *
 * @author Peter Schachte schachte@unimelb.edu.au
 * 
 */

package handValue; 
public enum CribbageRank {
    ACE('A'),
    TWO('2'),
    THREE('3'),
    FOUR('4'),
    FIVE('5'),
    SIX('6'),
    SEVEN('7'),
    EIGHT('8'),
    NINE('9'),
    TEN('T'),
    JACK('J'),
    QUEEN('Q'),
    KING('K'); 

    private final char abbrev;

    public char abbrev() {
        return this.abbrev;
    }

    public int faceValue() {
        return Math.min(this.ordinal() + 1, 10);
    }

    public CribbageRank nextHigher() {
        int value = this.ordinal() + 1;
        return value >= values().length ? null : values()[value];
    }

    public CribbageRank nextLower() {
        int value = this.ordinal() - 1;
        return value < 0 ? null : values()[value];
    }

    private CribbageRank(char abbrev) {
        this.abbrev = abbrev;
    }

    public String toString() {
        return Character.toString(this.abbrev);
    }
    
    public static CribbageRank fromString(char text) {
    	char cardChar = text;
    	for (CribbageRank r : CribbageRank.values()) {
    		if (cardChar == r.toString().charAt(0)) {
    			return r;
    		}
    	}
    	return null;
    }
}
